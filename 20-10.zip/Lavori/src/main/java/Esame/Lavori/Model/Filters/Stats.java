package Esame.Lavori.Model.Filters;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Vector;


public class Stats extends StatsAndFilters{

	private Vector<String> contratto = new Vector<String>();
	private Vector<String> remoto = new Vector<String>();
	private Vector<String> impiegati = new Vector<String>();
	
	public void ReadFile(String citta)  
	{ 
		try
		{
			Scanner scan = new Scanner(new BufferedReader(new FileReader("C:\\Users\\loren\\OneDrive\\Desktop\\Lavori\\Resources\\Python\\" + citta + ".txt")));
				/*for(int i = 0; scan.hasNextLine(); i++)
				{
					
					 if(i == 0 || i % prevAlGiorno == 0)
					{
						temperature.addElement((Double.parseDouble(scan.nextLine())));
						feels_like.addElement((Double.parseDouble(scan.nextLine())));
						temp_min.addElement((Double.parseDouble(scan.nextLine())));
						temp_max.addElement((Double.parseDouble(scan.nextLine())));
					} 
					else 
						for(int j = 0; j < datiPerOgniPrev; j++) 
							scan.nextLine();*/
 			for (int i = 0; scan.hasNextLine(); i++) {
 				if ( i == 1) i++;
 				
 			}
		}catch(FileNotFoundException e){
				System.out.print(e);
		}catch(Exception e){
			System.out.print(e);
		}
	}
}
