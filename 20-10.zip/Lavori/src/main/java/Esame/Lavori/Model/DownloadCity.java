package Esame.Lavori.Model;
/**
 * 
 * Classe che fa dowload dei dati che verranno poi usati.
 *
 */
public class DownloadCity {
	
	/**
	 * Stringa che indica la città nella quale cercare il lavoro.
	 */
	private String city_name;
	
	/**
	 * Stringa che definisce il tipo di contratto.
	 */
	private String employment_type;
	
	/**
	 * Stringa che indica il personale all'interno dell'azienda.
	 */
	private String company_num_employees;
	
	/**
	 *Stringa che indica se il lavoro può essere da remoto o meno. 
	 */
	private String remote;
	
	private String company_name;
	
	private String role;
	
	private String date_posted;
	
	public DownloadCity() {
		super();
		
	}
	
	/**
	 * Costruttore della Classe DowloadCity con i segienti parametri: 
	 * 
	 * @param key_word  
	 * @param city_name 
	 * @param employment_type
	 * @param company_num_employees
	 * @param remote
	 */
	
	public DownloadCity( String city_name, String employment_type, String company_num_employees, 
			String remote , String company_name, String role, String date_posted )
	{

		this.city_name = city_name;
		this.employment_type = employment_type;
		this.company_num_employees = company_num_employees;
		this.remote = remote;
		this.company_name = company_name;
		this.role = role;
		this.date_posted = date_posted;
		
	}

	public String getCompany_name() {
		return company_name;
	}

	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getDate_posted() {
		return date_posted;
	}

	public void setDate_posted(String date_posted) {
		this.date_posted = date_posted;
	}

	public String getCity_name() {
		return city_name;
	}

	public void setCity_name(String city_name) {
		this.city_name = city_name;
	}

	public String getEmployment_type() {
		return employment_type;
	}

	public void setEmployment_type(String employment_type) {
		this.employment_type = employment_type;
	}

	public String getCompany_num_employees() {
		return company_num_employees;
	}

	public void setCompany_num_employees(String company_num_employees) {
		this.company_num_employees = company_num_employees;
	}

	public String getRemote() {
		return remote;
	}

	public void setRemote(String remote) {
		this.remote = remote;
	}
	
}
	
	

