package Esame.Lavori.Model.Filters;

import java.io.FileNotFoundException;
import java.util.HashMap;

public abstract class StatsAndFilters {
	
	protected String p_chiave;
	protected String n_citta;
	protected HashMap <String, String> dati_usati = new HashMap<String, String>();
	
	
	
	/*protected String citta;
	protected HashMap<String,Double> variance_temperature = new HashMap<String,Double>();
	protected HashMap<String,Double> arithmetic_average_temperature = new HashMap<String,Double>();
	public abstract void ReadFile(String string) throws FileNotFoundException;
	public abstract HashMap<String, Double> methodVariance();
	public abstract HashMap<String, Double> methodMedia();*/
}
