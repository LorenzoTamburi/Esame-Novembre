package Esame.Lavori;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LavoriApplication {

	public static void main(String[] args) {
		SpringApplication.run(LavoriApplication.class, args);
	}

}
